// ExampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Example.h"
#include "ExampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExampleDlg dialog

CExampleDlg::CExampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExampleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExampleDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExampleDlg)
	DDX_Control(pDX, IDC_BUTTON3, m_Btn3);
	DDX_Control(pDX, IDC_BUTTON2, m_Btn2);
	DDX_Control(pDX, IDC_BUTTON1, m_Btn1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CExampleDlg, CDialog)
	//{{AFX_MSG_MAP(CExampleDlg)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExampleDlg message handlers

BOOL CExampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// create the tooltip control
	// register the dialog controls with the tooltip
	m_ToolTip.Create(this);
	m_ToolTip.AddTool( &m_Btn1, IDS_TT_BTN1 );
	m_ToolTip.AddTool( &m_Btn2, IDS_TT_BTN2 );
	m_ToolTip.AddTool( &m_Btn3, IDS_TT_BTN3 );
	
  //Set images
  m_Btn1.SetImage( IDB_GREENBUTTON, 15 );
  m_Btn2.SetImage( IDB_REDBUTTON, 15 );
  m_Btn3.SetImage( IDB_REDBUTTON, 15 );

	// set the initial state of buttons
	m_Btn1.Depress(true);
	m_Btn2.Depress(true);

	return TRUE;  // return TRUE  unless you set the focus to a control
}


BOOL CExampleDlg::PreTranslateMessage(MSG* pMsg) 
{
	// handle the message for the tooltip before passing it on
	MSG msg = *pMsg;
	msg.hwnd = (HWND)m_ToolTip.SendMessage(TTM_WINDOWFROMPOINT,0,(LPARAM)&msg.pt);
	CPoint pt = pMsg->pt;
	if( msg.message >= WM_MOUSEFIRST && msg.message <= WM_MOUSELAST )
		::ScreenToClient(msg.hwnd, &pt );
	msg.lParam = MAKELONG(pt.x,pt.y);

	// now let the tooltip handle the event
	m_ToolTip.RelayEvent(&msg);		

	return CDialog::PreTranslateMessage(pMsg);
}

void CExampleDlg::OnButton4() 
{
  m_Btn1.Depress(!m_Btn1.IsDepressed());
}

void CExampleDlg::OnButton5() 
{
  m_Btn2.Depress(!m_Btn2.IsDepressed());
}

void CExampleDlg::OnButton6() 
{
  m_Btn3.Depress(!m_Btn3.IsDepressed());
}
